# JARVIS Android V1 — PWA edition

A phone-first Progressive Web App. It can be installed from a secure HTTPS website to the OPPO home screen without Android Studio.

## What works in this starter
- Futuristic animated hologram-style interface (CSS, not full 3D rendering)
- Text chat interface
- Browser speech recognition when supported
- Android/browser text-to-speech
- Offline time/date/greeting commands
- Local notes saved in browser storage
- Service worker caching for app shell
- Optional private backend URL for cloud AI responses

## Important limitations
- A PWA is not a full native Android application.
- Microphone speech recognition depends on browser/device speech services and may need internet. It is not guaranteed offline.
- Offline functionality is limited to local commands, notes and cached app files.
- Always-on wake word, background microphone, direct calls/SMS, notification access, deep app control and PC automation are not included.
- Cloud AI requires a separately hosted backend. Never put an OpenAI API key in browser JavaScript.
- The app shell is cached; backend requests still need internet.

## Build directly from your Android phone
You can edit the project with a mobile code editor such as Acode, or use a browser-based editor. One practical publishing path is GitHub Pages:

1. Download and extract `JARVIS_PWA_V1.zip` using your phone's file manager.
2. Open GitHub in Chrome and sign in/create an account.
3. Create a new public repository named `jarvis-pwa` (public is easiest for GitHub Pages).
4. Use the repository's **Add file → Upload files** option. Upload the contents of this extracted folder (index.html, styles.css, app.js, sw.js, manifest.webmanifest, README.md and icons folder). Do not upload the ZIP as the only file.
5. Commit the files to the `main` branch.
6. Open repository **Settings → Pages**.
7. Under Build and deployment, choose **Deploy from a branch**, select `main` and `/ (root)`, then Save.
8. Wait for GitHub Pages to publish. The site URL will look like `https://YOUR-USERNAME.github.io/jarvis-pwa/`.
9. Open that HTTPS URL in Chrome on your OPPO phone.
10. Chrome menu (⋮) → **Install app** or **Add to Home screen**. Confirm.
11. Launch JARVIS from the new home-screen icon.

GitHub Pages publishes static files only. It does not host the private Python/OpenAI backend. The local PWA features work without that backend.

## Using a mobile code editor
If you want to edit locally before publishing, install a trusted code editor such as Acode from its official distribution. Extract the ZIP, open the folder in the editor, and edit the files. Avoid entering API secrets into `app.js`.

## First-use tests
- `hello`
- `what time is it`
- `what is today's date`
- `remember note Buy groceries`
- `show notes`
- Tap TALK and say "What time is it?"
- Turn on airplane mode and test time/date/notes after the app has been installed and cached.

## Backend contract
In Settings, set an HTTPS endpoint ending in `/chat`. It must accept:
```json
{"message":"Hello JARVIS"}
```
and return:
```json
{"reply":"Hello. How can I help?"}
```
The backend must allow CORS requests from your deployed PWA origin. Use authentication and HTTPS before exposing it publicly. Store API keys on the backend only.

## Updating
After changing files and publishing, close and reopen the PWA. If old assets remain cached, clear the site data for the GitHub Pages site in Chrome settings, then reload. For future releases, update the cache name in `sw.js` (for example `jarvis-pwa-v2`).
