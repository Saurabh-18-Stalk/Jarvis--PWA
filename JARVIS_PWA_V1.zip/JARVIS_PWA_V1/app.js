const $ = (id) => document.getElementById(id);
const messagesEl = $("messages");
const promptEl = $("prompt");
const statusEl = $("statusText");
const connectionEl = $("connectionText");
const settingsDialog = $("settingsDialog");
const notesDialog = $("notesDialog");
let lastReply = "Hello. JARVIS is ready.";
let recognition = null;

const store = {
  get(key, fallback = "") { try { return localStorage.getItem(key) ?? fallback; } catch { return fallback; } },
  set(key, value) { try { localStorage.setItem(key, value); } catch {} }
};

function addMessage(from, text) {
  const article = document.createElement("article");
  article.className = `message ${from === "YOU" ? "user" : "jarvis"}`;
  const speaker = document.createElement("div");
  speaker.className = "speaker";
  speaker.textContent = from;
  const bubble = document.createElement("div");
  bubble.className = "bubble";
  bubble.textContent = text;
  article.append(speaker, bubble);
  messagesEl.appendChild(article);
  messagesEl.scrollTop = messagesEl.scrollHeight;
}

function say(text) {
  lastReply = text;
  if (!("speechSynthesis" in window)) return;
  window.speechSynthesis.cancel();
  const utterance = new SpeechSynthesisUtterance(text);
  utterance.lang = "en-IN";
  utterance.rate = 0.96;
  window.speechSynthesis.speak(utterance);
}

function getNotes() {
  try { return JSON.parse(store.get("jarvis_notes", "[]")); } catch { return []; }
}
function saveNote(note) {
  const notes = getNotes();
  notes.unshift({ text: note, at: new Date().toLocaleString() });
  store.set("jarvis_notes", JSON.stringify(notes.slice(0, 100)));
}
function localAnswer(command) {
  const q = command.trim();
  const lower = q.toLowerCase();
  if (/^(hi|hello|hey jarvis)$/.test(lower)) return "Hello. JARVIS is online and ready to assist.";
  if (lower.includes("time")) return `The time is ${new Date().toLocaleTimeString([], {hour:"2-digit", minute:"2-digit"})}.`;
  if (lower.includes("date") || lower.includes("today")) return `Today is ${new Date().toLocaleDateString([], {weekday:"long", day:"numeric", month:"long", year:"numeric"})}.`;
  if (lower.startsWith("remember note ")) {
    const note = q.slice(14).trim();
    if (!note) return "Please tell me what note to save.";
    saveNote(note);
    return "Your note has been saved on this phone.";
  }
  if (lower === "show notes" || lower === "read my notes") {
    const notes = getNotes();
    return notes.length ? `You have ${notes.length} saved notes. Open the Notes button to read them.` : "You do not have any saved notes.";
  }
  if (lower === "help" || lower === "what can you do") {
    return "I can tell the time and date, save notes, read your saved-note count, and connect to your private AI backend. Try: remember note Buy groceries.";
  }
  if (lower.includes("offline")) return "Local commands and saved notes work offline. Advanced AI answers require your configured backend and an internet connection.";
  return null;
}

async function askBackend(message) {
  const endpoint = store.get("jarvis_backend_url").trim();
  if (!endpoint) return null;
  try {
    const response = await fetch(endpoint, {
      method: "POST",
      headers: {"Content-Type":"application/json"},
      body: JSON.stringify({message})
    });
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    const data = await response.json();
    return typeof data.reply === "string" ? data.reply : "The backend response did not contain a reply field.";
  } catch (error) {
    console.warn("JARVIS backend unavailable", error);
    return "I could not reach your JARVIS backend. Check the server URL and connection. Your local commands still work.";
  }
}

async function processCommand(command) {
  const q = command.trim();
  if (!q) return;
  addMessage("YOU", q);
  statusEl.textContent = "PROCESSING";
  const local = localAnswer(q);
  let answer = local;
  if (answer === null) {
    connectionEl.textContent = store.get("jarvis_backend_url") ? "BACKEND CONFIGURED" : "LOCAL MODE";
    answer = await askBackend(q);
    if (!answer) answer = "I can handle time, date, and notes offline. To answer general questions, configure your private JARVIS backend in Settings.";
  }
  addMessage("JARVIS", answer);
  statusEl.textContent = "LOCAL SYSTEM READY";
  say(answer);
}

$("composer").addEventListener("submit", (event) => {
  event.preventDefault();
  const value = promptEl.value;
  promptEl.value = "";
  processCommand(value);
});

$("micBtn").addEventListener("click", () => {
  const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (!SpeechRecognition) {
    addMessage("JARVIS", "Speech recognition is not available in this browser. Try Chrome on Android or type your command.");
    return;
  }
  if (recognition) { try { recognition.stop(); } catch {} }
  recognition = new SpeechRecognition();
  recognition.lang = store.get("jarvis_language", "en-IN");
  recognition.interimResults = false;
  recognition.maxAlternatives = 1;
  recognition.onstart = () => { statusEl.textContent = "LISTENING"; $("micBtn").innerHTML = "◉ LISTENING"; };
  recognition.onresult = (event) => processCommand(event.results[0][0].transcript);
  recognition.onerror = (event) => addMessage("JARVIS", `Voice input error: ${event.error}. You can type your command instead.`);
  recognition.onend = () => { statusEl.textContent = "LOCAL SYSTEM READY"; $("micBtn").innerHTML = "🎙 TALK"; };
  try { recognition.start(); } catch { addMessage("JARVIS", "Microphone could not start. Please try again."); }
});

$("speakBtn").addEventListener("click", () => say(lastReply));
$("clearBtn").addEventListener("click", () => { messagesEl.replaceChildren(); });
$("settingsBtn").addEventListener("click", () => {
  $("backendUrl").value = store.get("jarvis_backend_url");
  $("language").value = store.get("jarvis_language", "en-IN");
  settingsDialog.showModal();
});
$("saveSettings").addEventListener("click", () => {
  const url = $("backendUrl").value.trim();
  if (url && !url.startsWith("https://") && !url.startsWith("http://localhost")) {
    alert("Use an HTTPS backend URL. HTTP is only allowed for localhost during development.");
    return;
  }
  store.set("jarvis_backend_url", url);
  store.set("jarvis_language", $("language").value);
  connectionEl.textContent = url ? "BACKEND CONFIGURED" : "LOCAL MODE";
  settingsDialog.close();
});
$("notesBtn").addEventListener("click", () => {
  const notes = getNotes();
  const list = $("notesList");
  list.replaceChildren();
  if (!notes.length) {
    const p = document.createElement("p");
    p.className = "hint";
    p.textContent = "No notes saved yet. Try: remember note Call the dentist.";
    list.appendChild(p);
  } else {
    notes.forEach(note => {
      const div = document.createElement("div");
      div.className = "note";
      div.textContent = `${note.text} — ${note.at}`;
      list.appendChild(div);
    });
  }
  notesDialog.showModal();
});
$("closeNotes").addEventListener("click", () => notesDialog.close());

if ("serviceWorker" in navigator && location.protocol.startsWith("http")) {
  window.addEventListener("load", () => navigator.serviceWorker.register("./sw.js").catch(console.error));
}
if (store.get("jarvis_backend_url")) connectionEl.textContent = "BACKEND CONFIGURED";
